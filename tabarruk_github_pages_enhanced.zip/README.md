# Whispers of the Awaited One — Digital Tabarruk Card (Enhanced)

This repo is ready for GitHub Pages and includes:
- `index.html` with Open Graph/twitter metadata for rich previews
- Copy Link / WhatsApp / Telegram share buttons
- RTL toggle for Arabic/Urdu
- Print button
- `preview.jpg` for link previews (replace with your own image if you like)

## Publish on GitHub Pages
1. Create a GitHub repo (e.g., `tabarruk-card`).
2. Upload these files to the repo root.
3. Settings → Pages → Source: **Deploy from a branch** → Branch: **main** → **/** → Save.
4. Your link will be: `https://<username>.github.io/<repo>/`

### Optional
- Replace `preview.jpg` with a custom image (1200×630 recommended).
- Edit the `<title>` and `<meta name="description">` in `index.html` if needed.